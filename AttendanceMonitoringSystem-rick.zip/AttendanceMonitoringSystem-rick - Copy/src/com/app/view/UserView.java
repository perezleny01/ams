/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.app.view;

import com.app.controller.UserController;
import com.app.model.User;

import static com.app.view.MainView.GREEN;
import static com.app.view.MainView.RESET;
import java.util.Scanner;


public class UserView {
    
    Scanner scan = new Scanner(System.in);
    UserController user_control = new UserController();
         
    
    
    public void UserView(){  
                        
        boolean running = true;
        while(running){
            System.out.println("---------- Please select ----------");
            System.out.println("    [1] Register");
            System.out.println("    [2] Login");
            System.out.println("    [3] Exit");
            
            System.out.println("Enter a choice: ");
            
            try {
                String choice =  scan.nextLine();
                
                switch(choice){
                    case "1":
                        createUserAccountView();
                        break;
                    case "2":
                         logInUserAccountView();
                        break;
                    case "3":
                       running = false;
                        
                                                      
                        
                        
                } //choice
            } catch (Exception e) {
            }
        
        }//while
        
    }//AttendanceView
    
    
    
    
    
    
    public void createUserAccountView(){
        User user = new User();
//        Schedule schedule = new Schedule();
//        Department department = new Department();     
        
        
        
              System.out.print("Enter User Name: ");
              user.setUserName(scan.nextLine()); 
              
              System.out.print("Enter Password: ");
              user.setUserpassword(scan.nextLine());
              System.out.println("    [1] administrator");
              System.out.println("    [2] User or Client");
              System.out.print("Enter User Type: ");
              user.setUserType(scan.nextInt());
              
              
              
              user_control.createUserAccount(user);
             //attendControl.addUser(attendance, user, department, schedule);
    
    }
    
    public void logInUserAccountView(){
        
               User user = new User();
        
              System.out.println("Enter User Name: ");
              user.setUserName(scan.nextLine()); 
              
              System.out.println("Enter Password: ");
              user.setUserpassword(scan.nextLine());
              
              System.out.print("    [1] administrator");
              System.out.print("    [2] User or Client");
              System.out.print("Enter User Type: ");           
              user.setUserType(scan.nextInt()); 
                                                 
              user_control.loginUserAccount(user);
              
              
    
    } //logInUserAccountView
    
    //USER CLIENT MENU OR VIEW
    public void viewUserApp(){
        printWelcomeMessage();
        UserChoice();
    }
    
    
    public void printWelcomeMessage() {
        Scanner scan = new Scanner(System.in);
        System.out.println(  "****************************************************************************************************************************************************************************");
        System.out.println(  "*        __  _____  _____    __  ___  __     __  ___     __    __      __ __   _   __   ___  _____   _   __   ___  ___    ___      ___  _ _   ___ _____    __  __ __       *");
        System.out.println(  "*       /  ||     ||     |  / _]|  \\ ||  \\   /  ||   |   /  ]  / _]    |  |  | / \\ |  \\ |   ||     | / \\ |  \\ |   ||   |  /  _]    /__/ | | | /__/|     |  / _]|  |  |      *");
        System.out.println(  "*      | 0 ||_   _||_   _| / [_ | _ ||   \\ | 0 || _ |  /  /  / [_     |_   _||   || _ | | | |_   _||   || D ) | | | _ | /  /     (  \\_ | | |( \\_ |_   _| / [_ |_   _|      *");
        System.out.println(  "*      |   |  | |    | |  |   _]| | || D  ||   || | | /  /  |   _]    | \\_/ || 0 || | | | |   | |  | 0 ||  /  | | | | ||  |       \\_  || - | \\_ |  | |  |   _]| \\_/ |      *");
        System.out.println(  "*      | _ |  | |    | |  |  [_ | | ||    || | || | |/   \\_ |  [_     |  |  ||   || | | | |   | |  |   || \\   | | | | ||  |__     / \\ ||__ |/ \\ |  | |  |  [_ |  |  |      *");
        System.out.println(  "*      | | |  | |    | |  |    || | ||    || | || | |\\     ||    |    |  |  ||   || | | | |   | |  |   ||  \\  | | | | |\\  o  |    \\   ||   |\\   |  | |  |    ||  |  |      *");
        System.out.println(  "*      |_|_|  |_|    |_|  |____||_|_||___/_|_||_|_|_| \\____||____|    |__|__| \\_/ |_|_||___|  |_|   \\_/ |_|\\_||___||_|_| \\___/      \\__||__/  \\__|  |_|  |____||__|__|      *");
        System.out.println(  "*                                                                                                                                                                          *");
        System.out.println(  "****************************************************************************************************************************************************************************");
            
    }
    
    private String centerString(String str) {
        int CONSOLE_WIDTH = 80;
        int padding = (CONSOLE_WIDTH - str.length()) / 2; // Calculate padding
        StringBuilder centered = new StringBuilder();
        // Append spaces for padding
        for (int i = 0; i < Math.max(0, padding); i++) {
            centered.append(" ");
        }
        centered.append(str); // Append the original string
        return centered.toString();
    }
    
    
    public void UserChoice(){
        Scanner scan = new Scanner(System.in);
        System.out.println("\n");
        System.out.println(GREEN + "\t\t\t\tPlease select an option from the menu below:" + RESET);
        System.out.println(GREEN +  "\t\t\t\t\t\t1. USER PROFILE");
        System.out.println(GREEN + "\t\t\t\t\t\t2. TIME RECORD");
        System.out.println(GREEN + "\t\t\t\t\t\t3. MAKE ATTENDANCE"); 
        System.out.println(GREEN + "\t\t\t\t\t\t4. MAKE VIEW ATTENDANCE"); 
        System.out.println(GREEN + "\t\t\t\t\t\t5. EXIT");
        System.out.println();

        System.out.print(centerString("Enter a choice: "));
        try {
            int choice = scan.nextInt();
            switch (choice) {
                case 1:
                    // Call Temporary View for schedule Table
                    
                    break;
                case 2:
                    // Call Temporary View for department Table
                    break;
                case 3:
                    // Call Temporary View for user Table
                    break;
                case 4:
                    // Call Temporary View for attendance Table
                    AttendanceView attendanceview = new AttendanceView();                   
                    attendanceview.myAttendanceView();
                    
                    break;
                case 5:
                    // Exit the program
                    break;
                default:
                // Invalid input (use recursion)
            }
        } catch (Exception e) {
            System.out.println("Please enter a valid integer for the choice.");
            scan.nextLine();
            viewUserApp();
        }
    }
    
    
    
}//USerView class