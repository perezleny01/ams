/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.app.controller;

import com.app.db.DBConnection;
import com.app.model.User;
import com.app.view.MainView;
import com.app.view.UserView;


public class UserController extends DBConnection{
    
    public void createUserAccount(User user){
        
        
        try {
            connect();
                    prep = con.prepareStatement(CREATE_ACCOUNT);
                    prep.setString(1, user.getUserName());
                    prep.setString(2, user.getUserpassword());
                    prep.setInt(3, user.getUserType());                    
                   
             if(user.getUserName().isEmpty() || user.getUserpassword().isEmpty() || user.getUserType() == 0){
                 String  errorMessage = "Field cannot be Empty.";
                 System.out.println(errorMessage);
             } else{
             
                  prep.executeUpdate();
                  System.out.println("User " + user.getUserName() + " created succesfully!");
                  con.close();
             }                          
            
        } catch (Exception e) {
            System.out.println(e);
        }
    
    }// createUserAccount
    
     public void loginUserAccount(User user){
        
    
        try {
            connect();
            prep = con.prepareStatement(LOG_IN);
            prep.setString(1, user.getUserName());
            prep.setString(2, user.getUserpassword());
            prep.setInt(3, user.getUserType());
            
           
            result = prep.executeQuery();
            if(result.next()){
                int user_type = user.getUserType();
                
                if(user_type == 1){
                System.out.println("Logged In Successfully!");
                MainView mainview = new MainView();
                mainview.viewAdminApp();
                //system interface
                }
                else if(user_type == 2){
                System.out.println("not finished " + result.getInt("user_type") + "USER CLIENT");
                    UserView userview = new UserView();
                    userview.viewUserApp();
//                //system interface
                }
                
                
            }else{
                System.out.println("Logged In  Failed!");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    
    } //loginUserAccount
     
     
}
