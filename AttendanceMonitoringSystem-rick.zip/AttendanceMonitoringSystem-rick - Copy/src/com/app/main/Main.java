
package com.app.main;

import com.app.view.MainView;
import com.app.view.UserView;



public class Main {
    
    public static void main(String[] args) {
        
//        MainView view = new MainView();
//        view.viewApp();

        UserView userview = new UserView();
        userview.UserView();
        
        
      
        
        
    }//main
    
    
}//Main
