
package com.app.repository;

import com.app.model.Attendance;
import com.app.model.Department;
import com.app.model.Schedule;
import com.app.model.User;


public interface AttendanceRepository {
    

    // QUERY FOR ATTENDANCE
    public void ViewAttendance(Attendance attendance);
    public void ViewAttendanceUsingInnerJoin(Attendance attendance, Schedule schedule, Department department, User user);
    public void addUser(Attendance attendance, User user, Department department, Schedule schedule );
    public void searchUser(String UserKeyword);
    public void updateUser(Attendance attendance);
    public void deleteUser(Attendance attendance);
    public void archiveUser(Attendance attendance);
    public void retrieveUser(Attendance attendance);
    public void ViewUserArchivedUsingInnerJoin();
    
    // QUERY FOR USER ATTENDANCE
    public void ViewMyAttendance(Attendance attendance, Schedule schedule, Department department, User user);
    
    
    
}
